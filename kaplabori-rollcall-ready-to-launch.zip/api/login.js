import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).end('Method Not Allowed');
  }
  const { username, password } = req.body || {};
  // simple hardcoded auth - replace with proper user DB in production
  if (username === 'admin' && password === 'password') {
    const token = jwt.sign({ sub: 'admin', role: 'admin' }, JWT_SECRET, { expiresIn: '8h' });
    return res.status(200).json({ token });
  }
  return res.status(401).json({ error: 'Invalid credentials' });
}
