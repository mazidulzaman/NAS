import fs from 'fs/promises';
import path from 'path';
import jwt from 'jsonwebtoken';

const DB = path.resolve(process.cwd(), 'data', 'db.json');
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

function verifyToken(req) {
  const auth = req.headers?.authorization || req.headers?.Authorization || '';
  if (!auth) return null;
  const parts = auth.split(' ');
  if (parts.length !== 2) return null;
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded;
  } catch (e) {
    return null;
  }
}

export default async function handler(req, res) {
  try {
    const text = await fs.readFile(DB, 'utf8');
    const db = JSON.parse(text || '{}');
    if (req.method === 'GET') {
      const { date } = req.query || {};
      let records = db.attendance || [];
      if (date) records = records.filter(r => r.date === date);
      return res.status(200).json(records);
    } else if (req.method === 'POST') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const body = req.body; // expected { date: 'YYYY-MM-DD', records: [{studentId, status}] }
      const attendance = db.attendance || [];
      attendance.push({ id: Date.now().toString(), ...body });
      db.attendance = attendance;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(201).json(db.attendance[db.attendance.length-1]);
    } else if (req.method === 'PUT') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const body = req.body; // expected { id, date, records }
      const attendance = db.attendance || [];
      const idx = attendance.findIndex(a => a.id === body.id);
      if (idx === -1) return res.status(404).json({ error: 'Attendance record not found' });
      attendance[idx] = body;
      db.attendance = attendance;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(200).json(body);
    } else if (req.method === 'DELETE') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const id = req.query?.id;
      const attendance = (db.attendance || []).filter(a => a.id !== id);
      db.attendance = attendance;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(204).send('');
    } else {
      res.setHeader('Allow', 'GET,POST,PUT,DELETE');
      return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}
