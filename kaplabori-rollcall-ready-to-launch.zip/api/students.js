import fs from 'fs/promises';
import path from 'path';
import jwt from 'jsonwebtoken';

const DB = path.resolve(process.cwd(), 'data', 'db.json');
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

function verifyToken(req) {
  const auth = req.headers?.authorization || req.headers?.Authorization || '';
  if (!auth) return null;
  const parts = auth.split(' ');
  if (parts.length !== 2) return null;
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded;
  } catch (e) {
    return null;
  }
}

export default async function handler(req, res) {
  try {
    const text = await fs.readFile(DB, 'utf8');
    const db = JSON.parse(text || '{}');
    if (req.method === 'GET') {
      return res.status(200).json(db.students || []);
    } else if (req.method === 'POST') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const body = req.body;
      const students = db.students || [];
      const newStudent = Object.assign({ id: Date.now().toString() }, body);
      students.push(newStudent);
      db.students = students;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(201).json(newStudent);
    } else if (req.method === 'PUT') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const body = req.body;
      const students = db.students || [];
      const idx = students.findIndex(s => s.id === body.id);
      if (idx === -1) return res.status(404).json({ error: 'Student not found' });
      students[idx] = body;
      db.students = students;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(200).json(body);
    } else if (req.method === 'DELETE') {
      const auth = verifyToken(req);
      if (!auth) return res.status(401).json({ error: 'Unauthorized' });
      const id = req.query?.id;
      const students = (db.students || []).filter(s => s.id !== id);
      db.students = students;
      await fs.writeFile(DB, JSON.stringify(db, null, 2), 'utf8');
      return res.status(204).send('');
    } else {
      res.setHeader('Allow', 'GET,POST,PUT,DELETE');
      return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Server error' });
  }
}
