import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { School, LogIn } from "lucide-react";
import type { User } from "@/types/auth";
type Props = {
  onLogin: (user: User) => void;
};

// Default admin credentials - automatically created
const DEFAULT_ADMIN = {
  email: "admin@naekaplabori.edu",
  password: "admin123",
  user: {
    id: "admin-default",
    name: "Bhubaneswar Nath",
    email: "admin@naekaplabori.edu",
    role: "admin" as const,
    createdAt: new Date().toISOString()
  }
};
const LoginForm = ({
  onLogin
}: Props) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [role, setRole] = useState<'teacher' | 'admin'>("teacher");
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const normalizedEmail = email.trim().toLowerCase();

    // Simulate API call delay
    setTimeout(() => {
      let authenticatedUser: User | null = null;

      // Check default admin credentials
      if (email === DEFAULT_ADMIN.email && password === DEFAULT_ADMIN.password) {
        authenticatedUser = DEFAULT_ADMIN.user;
      } else {
        // Check dynamic user credentials
        const savedCredentials = JSON.parse(localStorage.getItem('attendance_user_credentials') || '[]');
        const savedUsers = JSON.parse(localStorage.getItem('attendance_users') || '[]');
        
        const matchingCredential = savedCredentials.find((cred: any) => 
          (cred.email || '').toLowerCase() === normalizedEmail && cred.password === password
        );
        
        if (matchingCredential) {
          const matchingUser = savedUsers.find((user: User) => user.id === matchingCredential.id);
          if (matchingUser) {
            authenticatedUser = matchingUser;
          }
        }
      }

      if (authenticatedUser) {
        onLogin(authenticatedUser);
        toast({
          title: "Login Successful",
          description: `Welcome, ${authenticatedUser.name}!`
        });
      } else {
        toast({
          title: "Login Failed",
          description: "Invalid email or password.",
          variant: "destructive"
        });
      }
      setIsLoading(false);
    }, 1000);
  };
  return <div className="min-h-screen bg-gradient-liquid-surface flex items-center justify-center p-4 animate-liquid-flow">
      <div className="w-full max-w-md space-y-6 animate-fade-in">
        {/* School Header */}
        <div className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-gradient-liquid-primary rounded-full flex items-center justify-center shadow-glass-lg backdrop-blur-glass animate-glass-float">
            <School className="w-10 h-10 text-primary" />
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-accent-foreground to-primary bg-clip-text text-transparent animate-liquid-pulse">
              National Academy of Education
            </h1>
            <p className="text-muted-foreground text-lg">Kaplabori • Attendance System</p>
          </div>
        </div>

        {/* Login Form */}
        <Card className="glass-card border-0 transition-liquid hover:shadow-glass-lg">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl font-semibold text-primary">
              {role === 'admin' ? 'Administrator Login' : 'Teacher Login'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <Label htmlFor="role" className="text-sm font-medium text-foreground mb-3 block">Login as</Label>
                <Select value={role} onValueChange={(value: 'teacher' | 'admin') => setRole(value)}>
                  <SelectTrigger id="role" className="glass-surface border-0 backdrop-blur-glass transition-liquid focus:shadow-glass">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent className="glass-surface backdrop-blur-glass border-0">
                    <SelectItem value="teacher" className="transition-liquid hover:bg-primary-glass">
                      👨‍🏫 Teacher
                    </SelectItem>
                    <SelectItem value="admin" className="transition-liquid hover:bg-primary-glass">
                      👨‍💼 Administrator
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="email" className="text-sm font-medium text-foreground mb-3 block">Email Address</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={email} 
                  onChange={e => setEmail(e.target.value)} 
                  placeholder="your.email@naekaplabori.edu" 
                  className="glass-surface border-0 backdrop-blur-glass transition-liquid focus:shadow-glass focus:bg-gradient-liquid-accent"
                  required 
                />
              </div>

              <div>
                <Label htmlFor="password" className="text-sm font-medium text-foreground mb-3 block">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={e => setPassword(e.target.value)} 
                  placeholder="Enter your password" 
                  className="glass-surface border-0 backdrop-blur-glass transition-liquid focus:shadow-glass focus:bg-gradient-liquid-accent"
                  required 
                />
              </div>

              <Button 
                type="submit" 
                className="w-full glass-button border-0 text-primary-foreground font-semibold py-3 text-lg"
                disabled={isLoading}
              >
                <LogIn className="w-5 h-5 mr-2" />
                {isLoading ? (
                  <span className="animate-liquid-pulse">Signing in...</span>
                ) : (
                  "Sign In"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Login Credentials Info */}
        <Card className="glass-surface border-0 backdrop-blur-glass transition-liquid hover:shadow-glass animate-scale-in">
          <CardContent className="space-y-2 text-sm text-muted-foreground p-4">
            <div className="text-center">
              <p className="text-xs opacity-80">Powered by Liquid Glass Design</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>;
};
export default LoginForm;