import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UserCheck, Users, BarChart3, Settings, LogOut, Shield } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import TakeAttendance from "./TakeAttendance";
import StudentsTab from "./StudentsTab";
import ReportsTab from "./ReportsTab";
import SettingsTab from "./SettingsTab";
import UserManagement from "./UserManagement";
import LoginForm from "./LoginForm";
import type { User } from "@/types/auth";

export type Student = {
  id: string;
  roll: number;
  name: string;
  guardianName: string;
  guardianPhone: string;
  class: number;
  section?: string;
};

export type AttendanceRecord = {
  id: string;
  studentId: string;
  date: string;
  status: 'present' | 'absent';
  class: number;
  section?: string;
};

const AttendanceApp = () => {
  const [user, setUser] = useState<User | null>(null);
  const [students, setStudents] = useState<Student[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  // Check for saved session on mount
  useEffect(() => {
    const savedSession = localStorage.getItem('attendance_session');
    if (savedSession) {
      setUser(JSON.parse(savedSession));
    }
  }, []);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedStudents = localStorage.getItem('attendance_students');
    const savedRecords = localStorage.getItem('attendance_records');
    
    if (savedStudents) {
      setStudents(JSON.parse(savedStudents));
    } else {
      // Start with empty student list - add students manually
      setStudents([]);
    }
    
    if (savedRecords) {
      setAttendanceRecords(JSON.parse(savedRecords));
    }
  }, []);

  // Save data to localStorage when changed
  useEffect(() => {
    localStorage.setItem('attendance_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('attendance_records', JSON.stringify(attendanceRecords));
  }, [attendanceRecords]);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    localStorage.setItem('attendance_session', JSON.stringify(loggedInUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('attendance_session');
    toast({
      title: "Logged Out", 
      description: "You have been logged out successfully"
    });
  };

  // Filter students and records based on user role and permissions
  const getAccessibleClasses = () => {
    if (!user) return [];
    if (user.role === 'admin') return Array.from({length: 12}, (_, i) => i + 1);
    return user.assignedClasses || [];
  };

  const filteredStudents = students.filter(student => 
    getAccessibleClasses().includes(student.class)
  );

  const filteredAttendanceRecords = attendanceRecords.filter(record =>
    getAccessibleClasses().includes(record.class)
  );

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* School Header */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground p-4 shadow-md">
        <div className="container mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">National Academy of Education</h1>
            <p className="text-sm opacity-90">Kaplabori • Attendance System</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-medium">{user.name}</p>
              <div className="flex items-center gap-1">
                {user.role === 'admin' ? (
                  <Shield className="w-3 h-3" />
                ) : (
                  <UserCheck className="w-3 h-3" />
                )}
                <span className="text-xs capitalize">{user.role}</span>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleLogout}
              className="text-primary-foreground hover:bg-white/20"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* User Role Badge */}
      <div className="container mx-auto p-4 max-w-md">
        <div className="mb-4 p-3 bg-accent rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span>Access Level:</span>
            <Badge variant={user.role === 'admin' ? "destructive" : "default"}>
              {user.role === 'admin' ? 'All Classes' : `Classes ${user.assignedClasses?.join(', ')}`}
            </Badge>
          </div>
          {user.role === 'teacher' && user.subjects && (
            <p className="text-xs text-muted-foreground mt-1">
              Subjects: {user.subjects.join(', ')}
            </p>
          )}
        </div>

        <Tabs defaultValue="attendance" className="w-full">
          <TabsList className={`grid w-full ${user.role === 'admin' ? 'grid-cols-5' : 'grid-cols-4'} mb-6`}>
            <TabsTrigger value="attendance" className="flex flex-col gap-1 p-3">
              <UserCheck className="w-4 h-4" />
              <span className="text-xs">Attendance</span>
            </TabsTrigger>
            <TabsTrigger value="students" className="flex flex-col gap-1 p-3">
              <Users className="w-4 h-4" />
              <span className="text-xs">Students</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex flex-col gap-1 p-3">
              <BarChart3 className="w-4 h-4" />
              <span className="text-xs">Reports</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex flex-col gap-1 p-3">
              <Settings className="w-4 h-4" />
              <span className="text-xs">Settings</span>
            </TabsTrigger>
            {user.role === 'admin' && (
              <TabsTrigger value="users" className="flex flex-col gap-1 p-3">
                <Shield className="w-4 h-4" />
                <span className="text-xs">Users</span>
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="attendance">
            <TakeAttendance 
              students={filteredStudents}
              attendanceRecords={filteredAttendanceRecords}
              setAttendanceRecords={setAttendanceRecords}
              userRole={user.role}
              accessibleClasses={getAccessibleClasses()}
            />
          </TabsContent>

          <TabsContent value="students">
            <StudentsTab 
              students={filteredStudents}
              setStudents={setStudents}
              allStudents={students}
              userRole={user.role}
              accessibleClasses={getAccessibleClasses()}
            />
          </TabsContent>

          <TabsContent value="reports">
            <ReportsTab 
              students={filteredStudents}
              attendanceRecords={filteredAttendanceRecords}
              accessibleClasses={getAccessibleClasses()}
            />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsTab currentUser={user} />
          </TabsContent>

          {user.role === 'admin' && (
            <TabsContent value="users">
              <UserManagement currentUser={user} />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
};

export default AttendanceApp;