import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { School, MessageCircle, Database, Info, Trash2 } from "lucide-react";
import type { User } from "@/types/auth";

type Props = {
  currentUser: User;
};

const SettingsTab = ({ currentUser }: Props) => {
  const [messageTemplate, setMessageTemplate] = useState(
    "Hello {guardian}, {student} (Roll {roll}) was {status} on {date} in {class}. - National Academy of Education, Kaplabori"
  );
  const [schoolName, setSchoolName] = useState("National Academy of Education");
  const [schoolLocation, setSchoolLocation] = useState("Kaplabori");
  const [autoSave, setAutoSave] = useState(true);

  const saveSettings = () => {
    localStorage.setItem('attendance_settings', JSON.stringify({
      messageTemplate,
      schoolName,
      schoolLocation,
      autoSave
    }));
    
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated"
    });
  };

  const clearAllData = () => {
    if (confirm("Are you sure? This will delete all students and attendance records. This action cannot be undone.")) {
      localStorage.removeItem('attendance_students');
      localStorage.removeItem('attendance_records');
      localStorage.removeItem('attendance_settings');
      
      toast({
        title: "Data Cleared",
        description: "All data has been deleted. Please refresh the page.",
        variant: "destructive"
      });
      
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };

  const exportData = () => {
    const data = {
      students: JSON.parse(localStorage.getItem('attendance_students') || '[]'),
      records: JSON.parse(localStorage.getItem('attendance_records') || '[]'),
      settings: JSON.parse(localStorage.getItem('attendance_settings') || '{}'),
      exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast({
      title: "Data Exported",
      description: "Backup file downloaded successfully"
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <School className="w-5 h-5" />
            School Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="schoolName">School Name</Label>
            <Input
              id="schoolName"
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              placeholder="Enter school name"
            />
          </div>
          
          <div>
            <Label htmlFor="schoolLocation">Location</Label>
            <Input
              id="schoolLocation"
              value={schoolLocation}
              onChange={(e) => setSchoolLocation(e.target.value)}
              placeholder="Enter location"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            WhatsApp Message Template
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="template">Message Template</Label>
            <Textarea
              id="template"
              value={messageTemplate}
              onChange={(e) => setMessageTemplate(e.target.value)}
              placeholder="Enter message template"
              rows={4}
            />
            <p className="text-sm text-muted-foreground mt-2">
              Available variables: {"{guardian}"}, {"{student}"}, {"{roll}"}, {"{status}"}, {"{date}"}, {"{class}"}
            </p>
          </div>
          
          <div className="p-3 bg-muted rounded-lg">
            <p className="text-sm font-medium mb-2">Preview:</p>
            <p className="text-sm">
              {messageTemplate
                .replace('{guardian}', 'Mrs. Sharma')
                .replace('{student}', 'Arjun Sharma')
                .replace('{roll}', '1')
                .replace('{status}', 'absent')
                .replace('{date}', 'Jan 15, 2024')
                .replace('{class}', '1')
              }
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Database className="w-5 h-5" />
            Data Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Auto-save attendance</p>
              <p className="text-sm text-muted-foreground">
                Automatically save attendance when marking students
              </p>
            </div>
            <Switch
              checked={autoSave}
              onCheckedChange={setAutoSave}
            />
          </div>
          
          <div className="pt-4 border-t">
            <div className="space-y-3">
              <Button onClick={exportData} variant="outline" className="w-full">
                <Database className="w-4 h-4 mr-2" />
                Export Data Backup
              </Button>
              
              <Button 
                onClick={clearAllData} 
                variant="destructive" 
                className="w-full"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All Data
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="w-5 h-5" />
            About
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm space-y-2">
            <p><strong>Attendance System</strong></p>
            <p>Mobile-first attendance tracking with WhatsApp integration</p>
            <p className="text-muted-foreground">
              Designed for Classes 1-12 • Built for {schoolName}, {schoolLocation}
            </p>
          </div>
          
          <div className="pt-4 border-t">
            <h4 className="font-medium mb-2">Features:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Quick attendance marking with visual feedback</li>
              <li>• Instant WhatsApp notifications to guardians</li>
              <li>• Monthly attendance reports and analytics</li>
              <li>• Offline-capable with local data storage</li>
              <li>• Touch-friendly mobile interface</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <div className="pb-6">
        <Button onClick={saveSettings} className="w-full">
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default SettingsTab;