import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Download, BarChart3, TrendingUp, TrendingDown } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns";
import { cn } from "@/lib/utils";
import type { Student, AttendanceRecord } from "./AttendanceApp";

type Props = {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  accessibleClasses: number[];
};

const ReportsTab = ({ students, attendanceRecords, accessibleClasses }: Props) => {
  const [selectedClass, setSelectedClass] = useState<number>(1);
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());

  const classStudents = students.filter(student => student.class === selectedClass);
  const monthStart = startOfMonth(selectedMonth);
  const monthEnd = endOfMonth(selectedMonth);
  
  // Get attendance records for the selected month and class
  const monthRecords = attendanceRecords.filter(record => {
    const recordDate = new Date(record.date);
    return record.class === selectedClass && 
           recordDate >= monthStart && 
           recordDate <= monthEnd;
  });

  // Calculate attendance statistics for each student
  const studentStats = classStudents.map(student => {
    const studentRecords = monthRecords.filter(record => record.studentId === student.id);
    const totalDays = studentRecords.length;
    const presentDays = studentRecords.filter(record => record.status === 'present').length;
    const percentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0;
    
    return {
      student,
      totalDays,
      presentDays,
      absentDays: totalDays - presentDays,
      percentage,
      status: percentage >= 75 ? 'good' : percentage >= 60 ? 'warning' : 'poor'
    };
  });

  // Class-wide statistics
  const classStats = {
    totalStudents: classStudents.length,
    avgAttendance: studentStats.length > 0 
      ? Math.round(studentStats.reduce((sum, stat) => sum + stat.percentage, 0) / studentStats.length)
      : 0,
    goodPerformers: studentStats.filter(stat => stat.status === 'good').length,
    warningCount: studentStats.filter(stat => stat.status === 'warning').length,
    poorPerformers: studentStats.filter(stat => stat.status === 'poor').length
  };

  const exportToCSV = () => {
    const csvData = [
      ['Roll', 'Student Name', 'Total Days', 'Present', 'Absent', 'Percentage', 'Status'],
      ...studentStats.map(stat => [
        stat.student.roll,
        stat.student.name,
        stat.totalDays,
        stat.presentDays,
        stat.absentDays,
        `${stat.percentage}%`,
        stat.status === 'good' ? 'Good' : stat.status === 'warning' ? 'Warning' : 'Poor'
      ])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `Class${selectedClass}_Attendance_${format(selectedMonth, 'MMM_yyyy')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const getStatusBadge = (status: string, percentage: number) => {
    switch (status) {
      case 'good':
        return <Badge className="bg-success text-success-foreground">{percentage}%</Badge>;
      case 'warning':
        return <Badge variant="secondary">{percentage}%</Badge>;
      case 'poor':
        return <Badge variant="destructive">{percentage}%</Badge>;
      default:
        return <Badge variant="outline">{percentage}%</Badge>;
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-lg">Attendance Reports</CardTitle>
          <Button onClick={exportToCSV} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Class</label>
              <Select value={selectedClass.toString()} onValueChange={(value) => setSelectedClass(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background border border-border z-50">
                  {accessibleClasses.map(classNum => (
                    <SelectItem key={classNum} value={classNum.toString()}>
                      Class {classNum}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Month</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !selectedMonth && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(selectedMonth, "MMM yyyy")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-background border border-border z-50">
                  <Calendar
                    mode="single"
                    selected={selectedMonth}
                    onSelect={(date) => date && setSelectedMonth(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Class Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Class Average</p>
                <p className="text-2xl font-bold">{classStats.avgAttendance}%</p>
              </div>
              <div className={`p-2 rounded-full ${classStats.avgAttendance >= 75 ? 'bg-success/20' : 'bg-destructive/20'}`}>
                {classStats.avgAttendance >= 75 ? 
                  <TrendingUp className="w-4 h-4 text-success" /> : 
                  <TrendingDown className="w-4 h-4 text-destructive" />
                }
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">{classStats.totalStudents}</p>
              </div>
              <div className="p-2 rounded-full bg-primary/20">
                <BarChart3 className="w-4 h-4 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Performance Distribution</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Good (≥75%)</p>
              <div className="text-lg font-bold text-success">{classStats.goodPerformers}</div>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Warning (60-74%)</p>
              <div className="text-lg font-bold text-secondary">{classStats.warningCount}</div>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Poor (&lt;60%)</p>
              <div className="text-lg font-bold text-destructive">{classStats.poorPerformers}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Student List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            Class {selectedClass} - {format(selectedMonth, 'MMMM yyyy')}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {studentStats.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              <BarChart3 className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No attendance data available</p>
              <p className="text-sm">Mark attendance to see reports</p>
            </div>
          ) : (
            <div className="divide-y">
              {studentStats
                .sort((a, b) => b.percentage - a.percentage)
                .map(stat => (
                <div key={stat.student.id} className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                      {stat.student.roll}
                    </div>
                    <div>
                      <p className="font-medium">{stat.student.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {stat.presentDays}/{stat.totalDays} days present
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    {getStatusBadge(stat.status, stat.percentage)}
                    <p className="text-xs text-muted-foreground mt-1">
                      {stat.absentDays} absent
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsTab;