import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "@/hooks/use-toast";
import { CalendarIcon, MessageCircle, Save, Users } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import type { Student, AttendanceRecord } from "./AttendanceApp";

type Props = {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  setAttendanceRecords: (records: AttendanceRecord[]) => void;
  userRole: 'admin' | 'teacher';
  accessibleClasses: number[];
};

const TakeAttendance = ({ students, attendanceRecords, setAttendanceRecords, userRole, accessibleClasses }: Props) => {
  const [selectedClass, setSelectedClass] = useState<number>(accessibleClasses[0] || 1);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [attendanceState, setAttendanceState] = useState<Record<string, 'present' | 'absent'>>({});

  // Set initial class when accessibleClasses changes
  useEffect(() => {
    if (accessibleClasses.length > 0 && !accessibleClasses.includes(selectedClass)) {
      setSelectedClass(accessibleClasses[0]);
    }
  }, [accessibleClasses, selectedClass]);

  const classStudents = students.filter(student => student.class === selectedClass);
  const dateKey = format(selectedDate, 'yyyy-MM-dd');

  // Load existing attendance for the selected date
  useEffect(() => {
    const existingAttendance = attendanceRecords
      .filter(record => record.date === dateKey && record.class === selectedClass)
      .reduce((acc, record) => {
        acc[record.studentId] = record.status;
        return acc;
      }, {} as Record<string, 'present' | 'absent'>);
    
    setAttendanceState(existingAttendance);
  }, [selectedDate, selectedClass, attendanceRecords, dateKey]);

  const toggleAttendance = (studentId: string) => {
    setAttendanceState(prev => ({
      ...prev,
      [studentId]: prev[studentId] === 'present' ? 'absent' : 'present'
    }));
  };

  const markAllPresent = () => {
    const newState = classStudents.reduce((acc, student) => {
      acc[student.id] = 'present';
      return acc;
    }, {} as Record<string, 'present' | 'absent'>);
    setAttendanceState(newState);
  };

  const markAllAbsent = () => {
    const newState = classStudents.reduce((acc, student) => {
      acc[student.id] = 'absent';
      return acc;
    }, {} as Record<string, 'present' | 'absent'>);
    setAttendanceState(newState);
  };

  const saveAttendance = async () => {
    const newRecords = Object.entries(attendanceState).map(([studentId, status]) => ({
      id: `${studentId}-${dateKey}`,
      studentId,
      date: dateKey,
      status,
      class: selectedClass
    }));

    // Remove existing records for this date/class and add new ones
    const filteredRecords = attendanceRecords.filter(
      record => !(record.date === dateKey && record.class === selectedClass)
    );
    
    try {
    const token = localStorage.getItem('authToken');
    const resp = await fetch('/api/attendance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(token?{ 'Authorization': `Bearer ${token}` }:{}) },
      body: JSON.stringify({ date: dateKey, class: selectedClass, records: newRecords })
    });
    if (!resp.ok) throw new Error('Failed to save');
    const saved = await resp.json();
    // refresh attendance list from server
    const listResp = await fetch('/api/attendance');
    const all = listResp.ok ? await listResp.json() : [];
    setAttendanceRecords(all);
  } catch (err) {
    console.error(err);
    toast({ title: 'Save failed', description: 'Could not save attendance to server', variant: 'destructive' });
    return;
  }

    toast({
      title: "Attendance Saved ✓",
      description: `Saved for Class ${selectedClass} on ${format(selectedDate, 'MMM dd, yyyy')}`
    });
  };

  const notifyGuardians = () => {
    const absentStudents = classStudents.filter(student => 
      attendanceState[student.id] === 'absent'
    );

    if (absentStudents.length === 0) {
      toast({
        title: "No Absences",
        description: "All students are marked present today!"
      });
      return;
    }

    absentStudents.forEach(student => {
      const message = `Hello ${student.guardianName}, ${student.name} (Roll ${student.roll}) was absent on ${format(selectedDate, 'MMM dd, yyyy')} in Class ${selectedClass}. - National Academy of Education, Kaplabori`;
      const encodedMessage = encodeURIComponent(message);
      const whatsappLink = `https://wa.me/${student.guardianPhone}?text=${encodedMessage}`;
      
      // Open WhatsApp link (in a real app, you might batch these or show a confirmation)
      window.open(whatsappLink, '_blank');
    });

    toast({
      title: "Guardian Notifications Sent",
      description: `${absentStudents.length} WhatsApp messages prepared`
    });
  };

  const presentCount = Object.values(attendanceState).filter(status => status === 'present').length;
  const absentCount = Object.values(attendanceState).filter(status => status === 'absent').length;
  const totalMarked = presentCount + absentCount;
  const percentage = totalMarked > 0 ? Math.round((presentCount / totalMarked) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Controls Bar */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-lg">Take Attendance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Class</label>
              <Select value={selectedClass.toString()} onValueChange={(value) => setSelectedClass(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background border border-border z-50">
                  {accessibleClasses.map(classNum => (
                    <SelectItem key={classNum} value={classNum.toString()}>
                      Class {classNum}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "MMM dd") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-background border border-border z-50">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={markAllPresent} className="flex-1">
              All Present
            </Button>
            <Button variant="destructive" onClick={markAllAbsent} className="flex-1">
              All Absent
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary Strip */}
      <Card className="bg-accent">
        <CardContent className="p-4">
          <div className="flex justify-between items-center text-sm">
            <div className="flex gap-4">
              <span>Total: {classStudents.length}</span>
              <span className="text-success font-medium">Present: {presentCount}</span>
              <span className="text-danger font-medium">Absent: {absentCount}</span>
            </div>
            <Badge variant={percentage >= 75 ? "default" : percentage >= 60 ? "secondary" : "destructive"}>
              {percentage}%
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Student List */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span className="font-medium">Class {selectedClass} Students</span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {classStudents.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No students in Class {selectedClass}</p>
              <p className="text-sm">
                {userRole === 'teacher' 
                  ? "No students assigned to your classes" 
                  : "Add students from the Students tab"}
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {classStudents.map(student => (
                <div
                  key={student.id}
                  className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
                  onClick={() => toggleAttendance(student.id)}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                        {student.roll}
                      </div>
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">{student.guardianName}</p>
                      </div>
                    </div>
                  </div>
                  
                  <Button
                    variant={attendanceState[student.id] === 'present' ? 'default' : 
                             attendanceState[student.id] === 'absent' ? 'destructive' : 'outline'}
                    size="sm"
                    className="min-w-[80px] h-12"
                  >
                    {attendanceState[student.id] === 'present' ? 'Present' :
                     attendanceState[student.id] === 'absent' ? 'Absent' : 'Mark'}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      {classStudents.length > 0 && (
        <div className="space-y-3 pb-6">
          <Button onClick={saveAttendance} className="w-full h-12">
            <Save className="w-4 h-4 mr-2" />
            Save Attendance
          </Button>
          
          <Button 
            variant="secondary" 
            onClick={notifyGuardians} 
            className="w-full h-12"
            disabled={absentCount === 0}
          >
            <MessageCircle className="w-4 h-4 mr-2" />
            Notify Guardians ({absentCount})
          </Button>
        </div>
      )}
    </div>
  );
};



// --- API integration: save attendance via backend ---
async function saveAttendanceAPI(date, records) {
  try {
    const payload = { date, records }; // records: [{ studentId, status }]
    const data = await fetchWithAuth('/attendance', { method: 'POST', body: JSON.stringify(payload) });
    toast({ title: 'Attendance saved to server.' });
    return data;
  } catch (err) {
    console.error('saveAttendanceAPI error', err);
    toast({ title: 'Failed to save attendance to server.', description: String(err) });
    throw err;
  }
}


export default TakeAttendance;