import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Users, UserCheck, Shield } from "lucide-react";
import type { User } from "@/types/auth";

type Props = {
  currentUser: User;
};

const UserManagement = ({ currentUser }: Props) => {
  const [users, setUsers] = useState<User[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "teacher" as "admin" | "teacher",
    assignedClasses: [] as number[],
    subjects: [] as string[]
  });

  const availableSubjects = [
    "Mathematics", "English", "Science", "Social Studies", 
    "Hindi", "Physics", "Chemistry", "Biology", "Computer Science"
  ];

  // Load users from localStorage
  useEffect(() => {
    const savedUsers = localStorage.getItem('attendance_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // Start with empty user list - add users manually
      setUsers([]);
    }
  }, []);

  // Save users to localStorage
  useEffect(() => {
    localStorage.setItem('attendance_users', JSON.stringify(users));
  }, [users]);

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      password: "",
      role: "teacher",
      assignedClasses: [],
      subjects: []
    });
    setEditingUser(null);
  };

  const openDialog = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData({
        name: user.name,
        email: user.email,
        password: "", // Don't pre-fill password for security
        role: user.role,
        assignedClasses: user.assignedClasses || [],
        subjects: user.subjects || []
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.email.trim() || (!editingUser && !formData.password.trim())) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Check for duplicate email
    const existingUser = users.find(u => 
      u.email.trim().toLowerCase() === formData.email.trim().toLowerCase() && u.id !== editingUser?.id
    );

    if (existingUser) {
      toast({
        title: "Email Already Exists",
        description: "This email is already registered",
        variant: "destructive"
      });
      return;
    }

    if (editingUser) {
      // Update existing user
      const updatedUsers = users.map(user =>
        user.id === editingUser.id
          ? {
              ...user,
              name: formData.name.trim(),
              email: formData.email.trim().toLowerCase(),
              role: formData.role,
              assignedClasses: formData.role === 'teacher' ? formData.assignedClasses : undefined,
              subjects: formData.role === 'teacher' ? formData.subjects : undefined
            }
          : user
      );
      setUsers(updatedUsers);
      
      // Sync credentials (email + optional password)
      {
        const savedCredentials = JSON.parse(localStorage.getItem('attendance_user_credentials') || '[]');
        const updatedCredentials = savedCredentials.map((cred: any) =>
          cred.id === editingUser.id
            ? {
                ...cred,
                email: formData.email.trim().toLowerCase(),
                ...(currentUser.role === 'admin' && formData.password.trim()
                  ? { password: formData.password.trim() }
                  : {})
              }
            : cred
        );
        localStorage.setItem('attendance_user_credentials', JSON.stringify(updatedCredentials));
      }
      
      toast({
        title: "User Updated",
        description: `${formData.name} updated successfully`
      });
    } else {
      // Add new user
      const userId = Date.now().toString();
      const newUser: User = {
        id: userId,
        name: formData.name.trim(),
        email: formData.email.trim().toLowerCase(),
        role: formData.role,
        assignedClasses: formData.role === 'teacher' ? formData.assignedClasses : undefined,
        subjects: formData.role === 'teacher' ? formData.subjects : undefined,
        createdAt: new Date().toISOString()
      };
      
      setUsers([...users, newUser]);
      
      // Store credentials separately
      const savedCredentials = JSON.parse(localStorage.getItem('attendance_user_credentials') || '[]');
      const newCredentials = {
        id: userId,
        email: formData.email.trim().toLowerCase(),
        password: formData.password.trim()
      };
      localStorage.setItem('attendance_user_credentials', JSON.stringify([...savedCredentials, newCredentials]));
      
      toast({
        title: "User Added",
        description: `${formData.name} added successfully`
      });
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const deleteUser = (user: User) => {
    if (user.id === currentUser.id) {
      toast({
        title: "Cannot Delete",
        description: "You cannot delete your own account",
        variant: "destructive"
      });
      return;
    }

    if (confirm(`Are you sure you want to delete ${user.name}?`)) {
      setUsers(users.filter(u => u.id !== user.id));
      
      // Remove credentials
      const savedCredentials = JSON.parse(localStorage.getItem('attendance_user_credentials') || '[]');
      const updatedCredentials = savedCredentials.filter((cred: any) => cred.id !== user.id);
      localStorage.setItem('attendance_user_credentials', JSON.stringify(updatedCredentials));
      
      toast({
        title: "User Deleted",
        description: `${user.name} removed from system`
      });
    }
  };

  const handleClassToggle = (classNum: number, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      assignedClasses: checked 
        ? [...prev.assignedClasses, classNum].sort((a, b) => a - b)
        : prev.assignedClasses.filter(c => c !== classNum)
    }));
  };

  const handleSubjectChange = (subject: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      subjects: checked
        ? [...prev.subjects, subject]
        : prev.subjects.filter(s => s !== subject)
    }));
  };

  const adminUsers = users.filter(u => u.role === 'admin');
  const teacherUsers = users.filter(u => u.role === 'teacher');

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Users className="w-5 h-5" />
            User Management
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => openDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingUser ? "Edit User" : "Add New User"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name*</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                    placeholder="Enter full name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email Address*</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                    placeholder="user@naekaplabori.edu"
                    required
                  />
                </div>

                {currentUser.role === 'admin' ? (
                  <div>
                    <Label htmlFor="password">Password{editingUser ? " (leave blank to keep current)" : "*"}</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({...prev, password: e.target.value}))}
                      placeholder={editingUser ? "Enter new password" : "Enter password"}
                      required={!editingUser}
                    />
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">
                    Only administrators can set or change passwords. Contact admin for updates.
                  </div>
                )}

                <div>
                  <Label htmlFor="role">Role*</Label>
                  <Select value={formData.role} onValueChange={(value: "admin" | "teacher") => setFormData(prev => ({...prev, role: value}))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="admin">Administrator</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.role === 'teacher' && (
                  <>
                    <div>
                      <Label>Assigned Classes</Label>
                      <div className="grid grid-cols-4 gap-2 mt-2">
                        {Array.from({length: 12}, (_, i) => i + 1).map(classNum => (
                          <div key={classNum} className="flex items-center space-x-2">
                            <Checkbox
                              id={`class-${classNum}`}
                              checked={formData.assignedClasses.includes(classNum)}
                              onCheckedChange={(checked) => handleClassToggle(classNum, checked as boolean)}
                            />
                            <Label htmlFor={`class-${classNum}`} className="text-sm">
                              {classNum}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label>Subjects</Label>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        {availableSubjects.map(subject => (
                          <div key={subject} className="flex items-center space-x-2">
                            <Checkbox
                              id={`subject-${subject}`}
                              checked={formData.subjects.includes(subject)}
                              onCheckedChange={(checked) => handleSubjectChange(subject, checked as boolean)}
                            />
                            <Label htmlFor={`subject-${subject}`} className="text-sm">
                              {subject}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingUser ? "Update" : "Add"} User
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
      </Card>

      {/* Administrators */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Administrators ({adminUsers.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {adminUsers.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              No administrators found
            </div>
          ) : (
            <div className="divide-y">
              {adminUsers.map(user => (
                <div key={user.id} className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center">
                      <Shield className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-medium">{user.name}</h3>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive">Admin</Badge>
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDialog(user)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteUser(user)}
                        disabled={user.id === currentUser.id}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Teachers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UserCheck className="w-4 h-4" />
            Teachers ({teacherUsers.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {teacherUsers.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              No teachers found
            </div>
          ) : (
            <div className="divide-y">
              {teacherUsers.map(user => (
                <div key={user.id} className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                      <UserCheck className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{user.name}</h3>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {user.assignedClasses?.map(classNum => (
                          <Badge key={classNum} variant="outline" className="text-xs">
                            Class {classNum}
                          </Badge>
                        ))}
                      </div>
                      {user.subjects && user.subjects.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {user.subjects.join(', ')}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openDialog(user)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteUser(user)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;