import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Plus, Search, Phone, User, Edit, Trash2 } from "lucide-react";
import type { Student } from "./AttendanceApp";


const getApiUrl = () => (process.env.REACT_APP_API_URL || process.env.VITE_API_URL || 'http://localhost:4000');

async function fetchWithAuth(path, options = {}) {
  const token = localStorage.getItem('kap_token'); // simple auth token management
  const headers = options.headers || {};
  headers['Content-Type'] = 'application/json';
  if (token) headers['Authorization'] = `Bearer ${token}`;
  options.headers = headers;
  const res = await fetch(getApiUrl() + path, options);
  if (!res.ok) {
    const txt = await res.text().catch(()=>null);
    throw new Error(txt || res.statusText);
  }
  return res.json().catch(()=>null);
}
type Props = {
  students: Student[];
  setStudents: (students: Student[]) => void;
  allStudents: Student[];
  userRole: 'admin' | 'teacher';
  accessibleClasses: number[];
};

const StudentsTab = ({ students, setStudents, allStudents, userRole, accessibleClasses }: Props) => 
  const authHeader = () => {
    const token = localStorage.getItem('authToken');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  };

  const createStudent = async (student) => {
    try {
      const resp = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify(student)
      });
      if (!resp.ok) throw new Error('Create failed');
      const saved = await resp.json();
      // refresh students
      const list = await (await fetch('/api/students')).json();
      setStudents(list);
      return saved;
    } catch (err) {
      console.error(err);
      toast({ title: 'Create failed', description: 'Could not create student', variant: 'destructive' });
      throw err;
    }
  };

  const updateStudentApi = async (student) => {
    try {
      const resp = await fetch('/api/students', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify(student)
      });
      if (!resp.ok) throw new Error('Update failed');
      const saved = await resp.json();
      const list = await (await fetch('/api/students')).json();
      setStudents(list);
      return saved;
    } catch (err) {
      console.error(err);
      toast({ title: 'Update failed', description: 'Could not update student', variant: 'destructive' });
      throw err;
    }
  };

  const deleteStudentApi = async (id) => {
    try {
      const resp = await fetch('/api/students?id=' + encodeURIComponent(id), {
        method: 'DELETE',
        headers: { ...authHeader() }
      });
      if (!resp.ok && resp.status !== 204) throw new Error('Delete failed');
      const list = await (await fetch('/api/students')).json();
      setStudents(list);
      return true;
    } catch (err) {
      console.error(err);
      toast({ title: 'Delete failed', description: 'Could not delete student', variant: 'destructive' });
      throw err;
    }
  };
{
  const [searchTerm, setSearchTerm] = useState("");
  const [classFilter, setClassFilter] = useState<number | "all">("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  
  const [formData, setFormData] = useState({
    roll: "",
    name: "",
    guardianName: "",
    guardianPhone: "",
    class: "1",
    section: ""
  });

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.roll.toString().includes(searchTerm);
    const matchesClass = classFilter === "all" || student.class === classFilter;
    return matchesSearch && matchesClass;
  });

  const resetForm = () => {
    setFormData({
      roll: "",
      name: "",
      guardianName: "",
      guardianPhone: "",
      class: "1",
      section: ""
    });
    setEditingStudent(null);
  };

  const openDialog = (student?: Student) => {
    if (student) {
      setEditingStudent(student);
      setFormData({
        roll: student.roll.toString(),
        name: student.name,
        guardianName: student.guardianName,
        guardianPhone: student.guardianPhone,
        class: student.class.toString(),
        section: student.section || ""
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim() || !formData.guardianName.trim() || !formData.guardianPhone.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const rollNumber = parseInt(formData.roll);
    if (isNaN(rollNumber) || rollNumber < 1) {
      toast({
        title: "Invalid Roll Number",
        description: "Roll number must be a positive number",
        variant: "destructive"
      });
      return;
    }

    // Check for duplicate roll numbers in the same class
    const existingStudent = allStudents.find(s => 
      s.roll === rollNumber && 
      s.class === parseInt(formData.class) &&
      s.id !== editingStudent?.id
    );

    if (existingStudent) {
      toast({
        title: "Duplicate Roll Number",
        description: `Roll ${rollNumber} already exists in Class ${formData.class}`,
        variant: "destructive"
      });
      return;
    }

    // Check if user has access to this class
    if (!accessibleClasses.includes(parseInt(formData.class))) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to manage this class",
        variant: "destructive"
      });
      return;
    }

    if (editingStudent) {
      // Update existing student
      const updatedStudents = allStudents.map(student =>
        student.id === editingStudent.id
          ? {
              ...student,
              roll: rollNumber,
              name: formData.name.trim(),
              guardianName: formData.guardianName.trim(),
              guardianPhone: formData.guardianPhone.trim(),
              class: parseInt(formData.class),
              section: formData.section.trim() || undefined
            }
          : student
      );
      setStudents(updatedStudents);
      toast({
        title: "Student Updated",
        description: `${formData.name} updated successfully`
      });
    } else {
      // Add new student
      const newStudent: Student = {
        id: Date.now().toString(),
        roll: rollNumber,
        name: formData.name.trim(),
        guardianName: formData.guardianName.trim(),
        guardianPhone: formData.guardianPhone.trim(),
        class: parseInt(formData.class),
        section: formData.section.trim() || undefined
      };
      
      setStudents([...allStudents, newStudent]);
      toast({
        title: "Student Added",
        description: `${formData.name} added to Class ${formData.class}`
      });
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const deleteStudent = (student: Student) => {
    if (confirm(`Are you sure you want to delete ${student.name}?`)) {
      deleteStudentApi(student.id);
      toast({
        title: "Student Deleted",
        description: `${student.name} removed from records`
      });
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-lg">Students</CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => openDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Add Student
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingStudent ? "Edit Student" : "Add New Student"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="roll">Roll Number*</Label>
                    <Input
                      id="roll"
                      type="number"
                      value={formData.roll}
                      onChange={(e) => setFormData(prev => ({...prev, roll: e.target.value}))}
                      min="1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="class">Class*</Label>
                    <Select value={formData.class} onValueChange={(value) => setFormData(prev => ({...prev, class: value}))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                  <SelectContent className="bg-background border border-border z-50">
                        {accessibleClasses.map(classNum => (
                          <SelectItem key={classNum} value={classNum.toString()}>
                            Class {classNum}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="name">Student Name*</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                    placeholder="Enter student name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="guardianName">Guardian Name*</Label>
                  <Input
                    id="guardianName"
                    value={formData.guardianName}
                    onChange={(e) => setFormData(prev => ({...prev, guardianName: e.target.value}))}
                    placeholder="Enter guardian name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="guardianPhone">Guardian Phone*</Label>
                  <Input
                    id="guardianPhone"
                    value={formData.guardianPhone}
                    onChange={(e) => setFormData(prev => ({...prev, guardianPhone: e.target.value}))}
                    placeholder="919876543210"
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Include country code (e.g., 919876543210 for India)
                  </p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingStudent ? "Update" : "Add"} Student
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or roll..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={classFilter.toString()} onValueChange={(value) => setClassFilter(value === "all" ? "all" : parseInt(value))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-background border border-border z-50">
                <SelectItem value="all">All Classes</SelectItem>
                {accessibleClasses.map(classNum => (
                  <SelectItem key={classNum} value={classNum.toString()}>
                    Class {classNum}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <div className="space-y-2">
        {filteredStudents.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No students found</p>
              <p className="text-sm">Add students to get started</p>
            </CardContent>
          </Card>
        ) : (
          filteredStudents.map(student => (
            <Card key={student.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-medium">
                      {student.roll}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{student.name}</h3>
                        <Badge variant="outline">Class {student.class}</Badge>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <User className="w-3 h-3" />
                        <span>{student.guardianName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Phone className="w-3 h-3" />
                        <span>{student.guardianPhone}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openDialog(student)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteStudent(student)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};



// --- Students API ---
async function loadStudentsAPI() {
  try {
    const data = await fetchWithAuth('/students', { method: 'GET' });
    return data || [];
  } catch (err) {
    console.error('loadStudentsAPI', err);
    toast({ title: 'Failed to load students', description: String(err) });
    return [];
  }
}

async function createStudentAPI(student) {
  try {
    const data = await fetchWithAuth('/students', { method: 'POST', body: JSON.stringify(student) });
    toast({ title: 'Student created' });
    return data;
  } catch (err) {
    console.error('createStudentAPI', err);
    toast({ title: 'Failed to create student', description: String(err) });
    throw err;
  }
}

async function updateStudentAPI(student) {
  try {
    const data = await fetchWithAuth('/students/' + student.id, { method: 'PUT', body: JSON.stringify(student) });
    toast({ title: 'Student updated' });
    return data;
  } catch (err) {
    console.error('updateStudentAPI', err);
    toast({ title: 'Failed to update student', description: String(err) });
    throw err;
  }
}

async function deleteStudentAPI(id) {
  try {
    await fetchWithAuth('/students/' + id, { method: 'DELETE' });
    toast({ title: 'Student deleted' });
  } catch (err) {
    console.error('deleteStudentAPI', err);
    toast({ title: 'Failed to delete student', description: String(err) });
    throw err;
  }
}


export default StudentsTab;