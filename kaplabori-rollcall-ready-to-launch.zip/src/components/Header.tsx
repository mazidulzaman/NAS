import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export default function Header() {
  const navigate = useNavigate();
  const token = typeof window !== 'undefined' ? localStorage.getItem('kap_token') : null;
  function logout() {
    localStorage.removeItem('kap_token');
    navigate('/login');
  }
  return (
    <div className="flex justify-end p-2">
      {token ? <Button onClick={logout}>Logout</Button> : <Button onClick={()=>navigate('/login')}>Login</Button>}
    </div>
  );
}
