import AttendanceApp from "../components/AttendanceApp";

const Index = () => {
  return <AttendanceApp />;
};

export default Index;
