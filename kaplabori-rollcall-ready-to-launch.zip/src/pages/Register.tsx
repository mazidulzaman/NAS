import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';

const API = () => (process.env.VITE_API_URL || 'http://localhost:4000');

export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await fetch(API() + '/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Register failed');
      localStorage.setItem('kap_token', data.token);
      toast({ title: 'Registered and logged in' });
      navigate('/');
    } catch (err) {
      console.error(err);
      toast({ title: 'Register failed', description: String(err) });
    }
  }

  return (
    <div className="max-w-md mx-auto mt-20">
      <Card>
        <CardHeader>
          <CardTitle>Register</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input value={name} onChange={e=>setName(e.target.value)} />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={email} onChange={e=>setEmail(e.target.value)} />
            </div>
            <div>
              <Label>Password</Label>
              <Input type="password" value={password} onChange={e=>setPassword(e.target.value)} />
            </div>
            <div className="flex gap-2">
              <Button type="submit">Register</Button>
              <Button variant="ghost" onClick={()=>navigate('/login')}>Login</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
