export type UserRole = 'admin' | 'teacher';

export type User = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  assignedClasses?: number[]; // For teachers
  subjects?: string[]; // For teachers
  createdAt: string;
};

export type UserCredentials = {
  id: string;
  email: string;
  password: string;
};

export type AuthState = {
  user: User | null;
  isAuthenticated: boolean;
};