import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.616fa259dce84e98af1950d6aa660c0d',
  appName: 'kaplabori-roll-call',
  webDir: 'dist',
  server: {
    url: 'https://616fa259-dce8-4e98-af19-50d6aa660c0d.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0
    }
  }
};

export default config;