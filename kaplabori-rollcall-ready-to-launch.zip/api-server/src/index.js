const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

const DB_PATH = path.resolve(__dirname, '..', 'data', 'dev.db');
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

if (!fs.existsSync(path.dirname(DB_PATH))) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
}

const db = new Database(DB_PATH);

// Initialize tables if not exist
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  password TEXT,
  name TEXT,
  createdAt TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  externalId TEXT,
  name TEXT,
  roll TEXT,
  class TEXT,
  section TEXT,
  createdAt TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT,
  studentId INTEGER,
  status TEXT,
  createdAt TEXT DEFAULT (datetime('now'))
);
`);

// seed admin user if not present
const adminEmail = 'admin@local';
const adminCheck = db.prepare('SELECT * FROM users WHERE email = ?').get(adminEmail);
if (!adminCheck) {
  const hash = bcrypt.hashSync('password', 10);
  db.prepare('INSERT INTO users (email, password, name) VALUES (?, ?, ?)').run(adminEmail, hash, 'Admin');
  console.log('Seeded admin user: admin@local / password');
}

// Auth endpoints
app.post('/auth/register', (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) return res.status(409).json({ error: 'User exists' });
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare('INSERT INTO users (email, password, name) VALUES (?, ?, ?)').run(email, hash, name || null);
  const user = { id: info.lastInsertRowid, email, name };
  const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  const ok = bcrypt.compareSync(password, user.password);
  if (!ok) return res.status(401).json({ error: 'invalid credentials' });
  const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
});

// middleware
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'no token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'invalid token' });
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// students
app.get('/students', authMiddleware, (req, res) => {
  const rows = db.prepare('SELECT * FROM students ORDER BY id ASC').all();
  res.json(rows);
});

app.post('/students', authMiddleware, (req, res) => {
  const { externalId, name, roll, class: cls, section } = req.body;
  const info = db.prepare('INSERT INTO students (externalId, name, roll, class, section) VALUES (?, ?, ?, ?, ?)').run(externalId || null, name, roll || null, cls || null, section || null);
  const s = db.prepare('SELECT * FROM students WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(s);
});

app.put('/students/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  const { externalId, name, roll, class: cls, section } = req.body;
  db.prepare('UPDATE students SET externalId=?, name=?, roll=?, class=?, section=? WHERE id=?').run(externalId || null, name, roll || null, cls || null, section || null, id);
  const s = db.prepare('SELECT * FROM students WHERE id = ?').get(id);
  res.json(s);
});

app.delete('/students/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  db.prepare('DELETE FROM students WHERE id = ?').run(id);
  res.status(204).send();
});

// attendance
app.get('/attendance', authMiddleware, (req, res) => {
  const { date } = req.query;
  let rows;
  if (date) rows = db.prepare('SELECT * FROM attendance WHERE date = ?').all(date);
  else rows = db.prepare('SELECT * FROM attendance').all();
  res.json(rows);
});

app.post('/attendance', authMiddleware, (req, res) => {
  const { date, records } = req.body;
  if (!Array.isArray(records)) return res.status(400).json({ error: 'records array required' });
  const created = [];
  const insert = db.prepare('INSERT INTO attendance (date, studentId, status) VALUES (?, ?, ?)');
  const transaction = db.transaction((recs) => {
    for (const r of recs) {
      const info = insert.run(date, r.studentId, r.status);
      created.push(db.prepare('SELECT * FROM attendance WHERE id = ?').get(info.lastInsertRowid));
    }
  });
  transaction(records);
  res.status(201).json(created);
});

app.put('/attendance/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  const { date, studentId, status } = req.body;
  db.prepare('UPDATE attendance SET date=?, studentId=?, status=? WHERE id=?').run(date, studentId, status, id);
  const a = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
  res.json(a);
});

app.delete('/attendance/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  db.prepare('DELETE FROM attendance WHERE id = ?').run(id);
  res.status(204).send();
});

app.get('/health', (req, res) => res.json({ ok: true }));

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log('API server listening on', port);
});
