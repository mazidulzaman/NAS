API server (Express + Prisma + SQLite)

Setup:
1. cd api-server
2. npm install
3. npx prisma generate
4. npx prisma db push
5. npm run dev

Notes:
- The server exposes /auth, /students, /attendance endpoints.
- It uses JWT for auth. Set JWT_SECRET in env for production.
