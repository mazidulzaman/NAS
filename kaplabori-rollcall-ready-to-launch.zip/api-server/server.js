const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

function requireAuth(req, res, next) {
  const auth = req.headers.authorization || '';
  if (!auth) return res.status(401).json({ error: 'Missing auth' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'Invalid auth format' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Auth route
app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ sub: user.id, role: user.role, username: user.username }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token });
});

// Seed route (dev) to create admin
app.post('/auth/seed', async (req, res) => {
  const { username='admin', password='password' } = req.body || {};
  const hashed = await bcrypt.hash(password, 8);
  try {
    const u = await prisma.user.create({ data: { username, password: hashed, role: 'admin' } });
    res.json({ ok: true, user: { id: u.id, username: u.username } });
  } catch (e) {
    res.status(400).json({ error: String(e) });
  }
});

// Students CRUD
app.get('/students', async (req, res) => {
  const students = await prisma.student.findMany();
  res.json(students);
});
app.post('/students', requireAuth, async (req, res) => {
  const body = req.body || {};
  const s = await prisma.student.create({ data: { name: body.name, roll: body.roll ? Number(body.roll): null, phone: body.phone || '', class: Number(body.class) } });
  res.status(201).json(s);
});
app.put('/students', requireAuth, async (req, res) => {
  const body = req.body || {};
  const s = await prisma.student.update({ where: { id: body.id }, data: { name: body.name, roll: body.roll ? Number(body.roll): null, phone: body.phone || '', class: Number(body.class) } });
  res.json(s);
});
app.delete('/students', requireAuth, async (req, res) => {
  const id = req.query.id;
  await prisma.student.delete({ where: { id } });
  res.status(204).send('');
});

// Attendance
app.get('/attendance', async (req,res) => {
  const { date } = req.query || {};
  if (date) {
    const recs = await prisma.attendance.findMany({ where: { date } });
    return res.json(recs);
  }
  const recs = await prisma.attendance.findMany();
  res.json(recs);
});
app.post('/attendance', requireAuth, async (req,res) => {
  const body = req.body || {};
  const rec = await prisma.attendance.create({ data: { date: body.date, class: Number(body.class), records: body.records } });
  res.status(201).json(rec);
});
app.put('/attendance', requireAuth, async (req,res) => {
  const body = req.body || {};
  const rec = await prisma.attendance.update({ where: { id: body.id }, data: { date: body.date, class: Number(body.class), records: body.records } });
  res.json(rec);
});
app.delete('/attendance', requireAuth, async (req,res) => {
  const id = req.query.id;
  await prisma.attendance.delete({ where: { id } });
  res.status(204).send('');
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('API server listening on', port));

