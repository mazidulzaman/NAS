
Ready-to-run package

This repository contains two parts:
- Frontend: kaplabori-roll-call-main-5 (Vite React app)
- API server: api-server (Express + better-sqlite3)

Quick start (Linux/macOS):

1) Start API server
   cd api-server
   npm install
   # dev.db is pre-seeded at api-server/data/dev.db
   npm run dev
   (Server runs at http://localhost:4000)

2) Start frontend
   cd kaplabori-roll-call-main-5
   npm install
   # create a .env file in the frontend folder with:
   # VITE_API_URL=http://localhost:4000
   npm run dev

Login:
- Use seeded admin: admin@local / password
- Or register via /register page in the frontend

Deployment:
- Deploy api-server to Railway/Render/Heroku and frontend to Vercel.
